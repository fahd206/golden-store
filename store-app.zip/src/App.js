import React, { useState } from \"react\";

export default function App() {
  const [products, setProducts] = useState([
    { id: 1, name: \"منتج 1\", price: 10000, image: \"https://via.placeholder.com/150\" },
    { id: 2, name: \"منتج 2\", price: 15000, image: \"https://via.placeholder.com/150\" },
  ]);

  const [adminMode, setAdminMode] = useState(false);
  const [code, setCode] = useState(\"\");
  const [newProduct, setNewProduct] = useState({ name: \"\", price: \"\", image: \"\" });

  const handleLogin = () => {
    if (code === \"2006\") {
      setAdminMode(true);
    } else {
      alert(\"الرمز غير صحيح\");
    }
  };

  const addProduct = () => {
    setProducts([...products, { id: Date.now(), ...newProduct }]);
    setNewProduct({ name: \"\", price: \"\", image: \"\" });
  };

  const deleteProduct = (id) => {
    setProducts(products.filter((p) => p.id !== id));
  };

  const getWhatsappLink = (product) => {
    const message = `أرغب في شراء المنتج ${product.name} بسعر ${product.price} دينار`;
    return `https://wa.me/9647700000000?text=${encodeURIComponent(message)}`; 
  };

  return (
    <div style={{padding: '20px', direction: 'rtl'}}>
      <h1>🛒 متجر المحل</h1>
      <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px'}}>
        {products.map((product) => (
          <div key={product.id} style={{border: '1px solid #ccc', padding: '10px', borderRadius: '8px'}}>
            <img src={product.image} alt={product.name} style={{width: '100%', height: '150px', objectFit: 'cover'}} />
            <h2>{product.name}</h2>
            <p>{product.price} دينار</p>
            <a href={getWhatsappLink(product)} target=\"_blank\" rel=\"noopener noreferrer\">
              شراء عبر واتساب
            </a><br/>
            {adminMode && (
              <button onClick={() => deleteProduct(product.id)} style={{marginTop: '5px'}}>حذف</button>
            )}
          </div>
        ))}
      </div>

      <div style={{marginTop: '20px', border: '1px solid #ccc', padding: '10px'}}>
        {!adminMode ? (
          <div>
            <h2>🔑 دخول الإشراف</h2>
            <input
              type=\"password\"
              placeholder=\"ادخل الرمز\"
              value={code}
              onChange={(e) => setCode(e.target.value)}
            />
            <button onClick={handleLogin}>دخول</button>
          </div>
        ) : (
          <div>
            <h2>➕ إضافة منتج</h2>
            <input
              type=\"text\"
              placeholder=\"اسم المنتج\"
              value={newProduct.name}
              onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
            />
            <input
              type=\"number\"
              placeholder=\"السعر\"
              value={newProduct.price}
              onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
            />
            <input
              type=\"text\"
              placeholder=\"رابط الصورة\"
              value={newProduct.image}
              onChange={(e) => setNewProduct({ ...newProduct, image: e.target.value })}
            />
            <button onClick={addProduct}>إضافة المنتج</button>
          </div>
        )}
      </div>
    </div>
  );
}
